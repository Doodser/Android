package com.example.lightcontrolproject

import kotlinx.serialization.Serializable

@Serializable
data class RoomObj(val id: String, val name: String)